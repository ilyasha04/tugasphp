<h2>Halaman Gesbuk</h2>
<p>Ini adalah halaman Gesbuk. Silakan isi buku tamu kami:</p>
<form action="proses_gesbuk.php" method="POST">
    <label for="nama">Nama:</label><br>
    <input type="text" id="nama" name="nama"><br><br>
    <label for="komentar">Komentar:</label><br>
    <textarea id="komentar" name="komentar" rows="4" cols="50"></textarea><br><br>
    <input type="submit" value="Kirim">
</form>
