<h2>Halaman Galeri</h2>
<p>Ini adalah halaman Galeri. Berikut adalah beberapa gambar dari galeri kami:</p>
<h3>kucing</h3>
<img src="https://2.bp.blogspot.com/-Y8iXCcdGFtg/V7cOEpBTVOI/AAAAAAAAAEE/QYAQSoymee40h0XjXRA6Qb84-4glAnuVACLcB/s1600/anak-kucing-lucu-12.jpg" alt="Gambar 1" width="300" height="200">
<img src="https://i.pinimg.com/736x/d4/6e/1d/d46e1d0f579d17a7259932d9bdafcbf0.jpg" alt="Gambar 2" width="300" height="200">
<img src="https://berbagaigadget.com/wp-content/uploads/2016/02/100-Gambar-dp-bbm-kucing-lucu-dan-gemesin-10.jpg" alt="Gambar 3" width="300" height="200">
<h3>ayam</h3>
<img src="https://4.bp.blogspot.com/-aZmbBTvHj44/V7B0W61pkHI/AAAAAAAAA7Q/l_0rhZv752sD-g5exzrmJPxWRZqMtjC3QCLcB/s1600/ayam.jpg" alt="gambar 4" width="300" height="200">
<img src="https://1.bp.blogspot.com/-4xW62sq4wac/TcavaD_vA4I/AAAAAAAADNg/VIJzIrpSbd0/s1600/gambar-ayam.jpg" alt="gambar 5" width="300" height="200">
<img src="https://blogpictures.99.co/memberi-makan-ayam.jpg" alt="gambar 6" width="300" height="200">
<h2>Terima Kasih Sudah Mengunjungi Galeri Kami!</h2>
<p>Kami ingin mengucapkan terima kasih yang tulus kepada Anda yang telah meluangkan waktu untuk menjelajahi galeri kami. Setiap langkah Anda di sini sangat berarti bagi kami.

Di dalam galeri ini, kami berusaha untuk menyajikan karya-karya yang mungkin menginspirasi, memukau, atau sekadar menghibur. Setiap foto, lukisan, atau karya seni visual yang Anda lihat memiliki cerita dan emosi di baliknya. Kami berharap Anda menemukan momen-momen yang menggetarkan hati atau sekadar mengalami keindahan dari sudut pandang yang baru.

Kami berterima kasih atas dukungan Anda, baik dalam mengapresiasi karya kami maupun dalam memberikan inspirasi untuk masa depan. Setiap kunjungan Anda di sini membantu kami tumbuh dan berkembang.

Jika Anda memiliki pertanyaan, komentar, atau ingin berbagi pengalaman dari galeri ini, jangan ragu untuk menghubungi kami. Kami senang mendengar tanggapan dari Anda.

Terima kasih sekali lagi, dan semoga galeri ini telah memberikan pengalaman yang berharga bagi Anda.</p>
