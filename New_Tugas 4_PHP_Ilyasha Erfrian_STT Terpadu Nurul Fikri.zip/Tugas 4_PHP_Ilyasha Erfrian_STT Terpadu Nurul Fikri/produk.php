<h2>Halaman Produk</h2>
<p>Ini adalah halaman Produk. Berikut adalah daftar produk yang kami tawarkan:</p>
<ul>
    <li>samsung galaxy A51</li>
    <img src="https://resources.claroshop.com/medios-plazavip/mkt/5e97346243132_celular-a51-blanco-1-jpg.jpg" alt="samsung" width="300" height="200">
    <p>Desain:

Dimensi: 158.5 x 73.6 x 7.9 mm
Berat: 172 gram
Material: Plastik
Layar:

Tipe: Super AMOLED capacitive touchscreen, 16M colors
Ukuran: 6.5 inci
Resolusi: 1080 x 2400 pixels
Rasio Layar ke Tubuh: ~87.4%
Pelindung Layar: Corning Gorilla Glass 3
Performa:

Chipset: Exynos 9611 (10nm)
CPU: Octa-core (4x2.3 GHz Cortex-A73 & 4x1.7 GHz Cortex-A53)
GPU: Mali-G72 MP3
Memori:

RAM: 4GB / 6GB
Penyimpanan Internal: 64GB / 128GB (dapat diperluas hingga 512GB dengan microSD)
Kamera Belakang:

48 MP, f/2.0, 26mm (wide), 1/2.0", 0.8µm, PDAF
12 MP, f/2.2, 12mm (ultrawide)
5 MP, f/2.4, (makro)
5 MP, f/2.2, (depth)
Fitur: LED flash, panorama, HDR
Video: 4K@30fps, 1080p@30/120fps; gyro-EIS
Kamera Depan:

32 MP, f/2.2, 26mm (wide), 1/2.8", 0.8µm
Fitur: HDR
Video: 1080p@30fps
Baterai:

Tipe: Li-Po 4000 mAh, non-removable
Pengisian: Pengisian cepat 15W
Fitur Lainnya:

OS: Android 10, upgradable to Android 11, One UI 3.1
Sensor: Fingerprint (under display, optical), accelerometer, gyro, proximity, compass
3.5mm jack: Yes
Speaker: Loudspeaker with stereo speakers
USB: USB Type-C 2.0
Warna:

Prism Crush Black, White, Blue, Pink
Harga (tergantung pasar dan waktu):

Sekitar $250 - $300</p>
    <li>Realme C33</li>
    <img src="https://cms.dailysocial.id/wp-content/uploads/2023/01/sg-11134201-22100-g26nq47wr2iv1c.jpeg" alt="realme" width="300" height="200">
    <p>Desain

Dimensi: 165.2 x 75.8 x 9.5 mm (6.50 x 2.98 x 0.37 in)
Berat: 209 gram
Bahan: Plastik
Layar

Tipe: IPS LCD capacitive touchscreen, 16M colors
Ukuran: 6.5 inches, 102.0 cm2 (~82.4% screen-to-body ratio)
Resolusi: 720 x 1600 pixels, 20:9 ratio (~270 ppi density)
Proteksi: Corning Gorilla Glass
Performa

OS: Android 11, Realme UI
Chipset: MediaTek Helio G70 (12 nm)
CPU: Octa-core (2x2.0 GHz Cortex-A75 & 6x1.7 GHz Cortex-A55)
GPU: Mali-G52 2EEMC2
Memori

Slot Kartu Memori: microSDXC (dedicated slot)
Internal: 32GB 2GB RAM, 64GB 3GB RAM
eMMC 5.1
Kamera Belakang

Dual Camera:
13 MP, f/2.2, (wide), PDAF
2 MP, f/2.4, (depth)
Fitur: LED flash, HDR, panorama
Video: 1080p@30fps
Kamera Depan

Single Camera:
5 MP, f/2.4, (wide)
Fitur: HDR
Video: 1080p@30fps
Suara

Speaker: Ya
Jack 3.5mm: Ya
Konektivitas

WLAN: Wi-Fi 802.11 b/g/n, hotspot
Bluetooth: 5.0, A2DP, LE
GPS: Yes, with A-GPS, GLONASS, BDS
USB: microUSB 2.0, USB On-The-Go
Fitur lainnya

Sensor: Fingerprint (rear-mounted), accelerometer, proximity, compass
Baterai

Tipe: Li-Po 5000 mAh, non-removable
Pengisian: Pengisian cepat 18W
Warna

Warna: Cross Blue, Cross Black
Harga (perkiraan)

Harga: Rp 1,5 juta (untuk varian 32GB/2GB RAM), Rp 1,7 juta (untuk varian 64GB/3GB RAM)</p>
    <li>Redmi Note 8</li>
    <img src="https://1.bp.blogspot.com/-3W-VlQ90C_U/YI-Zxn6dNII/AAAAAAAABQU/AKi6cU5aIGE9MrkZhCCzdieEeu_lcmvzACLcBGAsYHQ/s2048/101.Redmi%2Bnote%2B8.jpg" alt="redmi" width="300" height="200">
    <p>Desain

Dimensi: 158.3 x 75.3 x 8.4 mm (6.23 x 2.96 x 0.33 in)
Bobot: 190 gram
Material: Kaca depan dan belakang (Corning Gorilla Glass 5), frame plastik
Layar

Tipe: IPS LCD capacitive touchscreen, 16M colors
Ukuran: 6.3 inci, 97.4 cm2 (~81.7% screen-to-body ratio)
Resolusi: 1080 x 2340 pixels, 19.5:9 ratio (~409 ppi density)
Proteksi: Corning Gorilla Glass 5
Performa

Chipset: Qualcomm SDM665 Snapdragon 665 (11 nm)
CPU: Octa-core (4x2.0 GHz Kryo 260 Gold & 4x1.8 GHz Kryo 260 Silver)
GPU: Adreno 610
Memori

RAM: 3GB, 4GB, 6GB (Pilihan)
Internal: 32GB, 64GB, 128GB (Pilihan)
MicroSD: Slot khusus, hingga 256GB (gunakan SIM 2 slot)
Kamera Belakang

Quad: 48 MP, f/1.8, (wide), 1/2.0", 0.8µm, PDAF
8 MP, f/2.2, 13mm (ultrawide), 1/4.0", 1.12µm
2 MP, f/2.4, 1/5.0", 1.75µm (dedicated macro camera)
2 MP, f/2.4, 1/5.0", 1.75µm, depth sensor
Fitur: LED flash, HDR, panorama
Video: [email protected], [email protected]/60/120fps, [email protected]
Kamera Depan

Single: 13 MP, f/2.0, (wide), 1/3.1", 1.12µm
Fitur: HDR, panorama
Video: [email protected]
Baterai

Non-removable Li-Po 4000 mAh battery
Pengisian: Fast charging 18W
Fitur Lain

Sensor: Fingerprint (rear-mounted), accelerometer, gyro, proximity, compass
Jack Audio 3.5mm: Yes
NFC: Yes (market/region dependent)
Sistem Operasi

Android 9.0 (Pie), upgradable to Android 10, MIUI 12
Warna Pilihan

Neptune Blue, Moonlight White, Space Black, Nebula Purple
Harga

Harga awal (2024): Sekitar Rp 2.000.000 - Rp 2.500.000 (Tergantung varian memori)</p>
</ul>
