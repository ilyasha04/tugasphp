<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Web Dono</title>
</head>
<body>
    <h1 align="center">Web Dono</h1>

    <div style="text-align:center; background-color:khaki; color
    :blue">
    Home    | Produk    | Pesan     |  Galeri   | Gesbuk
    </div>

    <div style="height: 600px">
    Halaman Depan
    </div>

    <div style="text-align:center; background-color:black; color:white">
        Copyright @Dono - 2024
    </div>
</body>
</html>