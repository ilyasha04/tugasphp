<?php
// include / include_once -> potongan2 file
// require / require_once -> potongan2 file untuk isinya berupa function, class
// menggabungkannya beberapa file menjadi saru bentuk web utuh
include_once 'atas.php';
include_once 'isi.php';
include_once 'bawah.php';
?>