<h2>Halaman Produk</h2>
<p>Ini adalah halaman Produk. Berikut adalah daftar produk yang kami tawarkan:</p>
<ul>
    <li>samsung galaxy A51</li>
    <img src="https://resources.claroshop.com/medios-plazavip/mkt/5e97346243132_celular-a51-blanco-1-jpg.jpg" alt="samsung" width="300" height="200">
    <li>Realme C33</li>
    <img src="https://cms.dailysocial.id/wp-content/uploads/2023/01/sg-11134201-22100-g26nq47wr2iv1c.jpeg" alt="realme" width="300" height="200">
    <li>Redmi Note 8</li>
    <img src="https://1.bp.blogspot.com/-3W-VlQ90C_U/YI-Zxn6dNII/AAAAAAAABQU/AKi6cU5aIGE9MrkZhCCzdieEeu_lcmvzACLcBGAsYHQ/s2048/101.Redmi%2Bnote%2B8.jpg" alt="redmi" width="300" height="200">
</ul>
