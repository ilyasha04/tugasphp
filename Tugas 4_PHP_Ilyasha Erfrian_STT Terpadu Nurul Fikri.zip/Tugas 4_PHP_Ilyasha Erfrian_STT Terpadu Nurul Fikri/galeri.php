<h2>Halaman Galeri</h2>
<p>Ini adalah halaman Galeri. Berikut adalah beberapa gambar dari galeri kami:</p>
<img src="https://2.bp.blogspot.com/-Y8iXCcdGFtg/V7cOEpBTVOI/AAAAAAAAAEE/QYAQSoymee40h0XjXRA6Qb84-4glAnuVACLcB/s1600/anak-kucing-lucu-12.jpg" alt="Gambar 1" width="300" height="200">
<img src="https://i.pinimg.com/736x/d4/6e/1d/d46e1d0f579d17a7259932d9bdafcbf0.jpg" alt="Gambar 2" width="300" height="200">
<img src="https://berbagaigadget.com/wp-content/uploads/2016/02/100-Gambar-dp-bbm-kucing-lucu-dan-gemesin-10.jpg" alt="Gambar 3" width="300" height="200">
