<h2>Halaman Home</h2>
<p>Selamat datang di halaman Home. Ini adalah halaman utama dari website kami.</p>
<img src="https://www.desicomments.com/wp-content/uploads/2017/02/Welcome-Pic.jpg" alt="welcome" width="1000">
