<h2>Halaman Pesan</h2>
<p>Silakan isi formulir di bawah untuk mengirim pesan kepada kami:</p>
<form action="proses_pesan.php" method="POST">
    <label for="nama">Nama:</label><br>
    <input type="text" id="nama" name="nama"><br><br>
    <label for="pesan">Pesan:</label><br>
    <textarea id="pesan" name="pesan" rows="4" cols="50"></textarea><br><br>
    <input type="submit" value="Kirim">
</form>
